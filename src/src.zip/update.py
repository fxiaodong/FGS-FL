#!/usr/bin/env python
# -*- coding: utf-8 -*-

import copy
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from models import LowRankFC  # 确保导入 LowRankFC 以进行类型检查或逻辑参考


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = [int(i) for i in idxs]

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label


class LocalUpdate(object):
    def __init__(self, args, dataset, idxs, logger=None):
        self.args = args
        self.logger = logger
        # 划分： 80% train, 10% val, 10% test（至少1样本兜底）
        idxs = list(idxs)
        n = len(idxs)
        n_train = int(0.8 * n)
        n_val = int(0.1 * n)

        train_idxs = idxs[:max(1, n_train)]
        val_idxs = idxs[max(1, n_train): max(1, n_train) + max(1, n_val)]
        test_idxs = idxs[max(1, n_train) + max(1, n_val):] or idxs[:1]

        self.trainloader = DataLoader(DatasetSplit(dataset, train_idxs), batch_size=args.local_bs, shuffle=True)
        self.validloader = DataLoader(DatasetSplit(dataset, val_idxs), batch_size=max(1, len(val_idxs) // 10),
                                      shuffle=False)
        self.testloader = DataLoader(DatasetSplit(dataset, test_idxs), batch_size=max(1, len(test_idxs) // 10),
                                     shuffle=False)
        self.device = 'cuda' if args.gpu else 'cpu'
        self.criterion = nn.NLLLoss().to(self.device)

    def update_weights(self, model, global_round, compress=False):
        # model: copy of global model (on caller side may pass copy)
        model = model.to(self.device)
        model.train()

        # 优化器设置
        optimizer = torch.optim.SGD(model.parameters(), lr=self.args.lr, momentum=getattr(self.args, 'momentum', 0.5))

        epoch_losses = []
        for _ in range(self.args.local_ep):
            batch_losses = []
            for images, labels in self.trainloader:
                images, labels = images.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                outputs = model(images)
                loss = self.criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                batch_losses.append(loss.item())

            if batch_losses:
                epoch_losses.append(sum(batch_losses) / len(batch_losses))

        local_loss = sum(epoch_losses) / len(epoch_losses) if epoch_losses else 0.0

        # n_samples 用于 FedAvg 权重
        n_samples = sum([images.size(0) for images, _ in self.trainloader]) + sum(
            [images.size(0) for images, _ in self.validloader])

        # [cite_start]=== 核心修复：处理压缩模型的参数还原 === [cite: 7, 9, 153]
        # 如果模型经过了压缩 (LowRankFC)，state_dict 会包含 W1, W2。
        # 聚合服务器期望看到标准的 .weight。必须在这里还原，否则无法与全模型聚合。
        local_state = model.state_dict()
        new_state = {}

        for k, v in local_state.items():
            # 检查是否是压缩层的参数 (W1)
            if 'W1' in k:
                # 找到对应的层名，例如 "fc1.W1" -> "fc1"
                layer_name = k.replace('.W1', '')

                # 获取 W1 和 W2
                if f'{layer_name}.W2' in local_state:
                    w1 = local_state[f'{layer_name}.W1']
                    w2 = local_state[f'{layer_name}.W2']

                    # 还原权重 W = W1 @ W2
                    # W1形状: (out, rank), W2形状: (rank, in) => W形状: (out, in)
                    # 这与 nn.Linear 的 .weight 形状一致
                    full_weight = w1 @ w2

                    new_state[f'{layer_name}.weight'] = full_weight.cpu()

                    # 处理 Bias
                    if f'{layer_name}.bias' in local_state:
                        new_state[f'{layer_name}.bias'] = local_state[f'{layer_name}.bias'].cpu()
                else:
                    # 异常情况，照常复制
                    new_state[k] = v.cpu()

            elif 'W2' in k:
                # W2 已经在处理 W1 时被合并了，跳过
                continue
            else:
                # 普通层参数直接复制
                new_state[k] = v.cpu()

        payload = {
            'state': new_state,
            'n_samples': int(n_samples if n_samples > 0 else 1),
            'loss': float(local_loss)
            # eval_score 在 update 中无法计算（因为没有另一方的模型），移除或留空，
            # 改在 federated_main.py 的聚合阶段计算。
        }
        return payload, local_loss

    def inference(self, model):
        model = model.to(self.device)
        model.eval()
        total, correct = 0, 0
        loss = 0.0
        with torch.no_grad():
            for images, labels in self.testloader:
                images, labels = images.to(self.device), labels.to(self.device)
                outputs = model(images)
                batch_loss = self.criterion(outputs, labels)
                loss += batch_loss.item() * images.size(0)
                _, preds = torch.max(outputs, 1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)

        acc = correct / total if total > 0 else 0.0
        avg_loss = loss / total if total > 0 else 0.0
        return acc, avg_loss


# [update.py] 的末尾追加

def test_inference(args, model, test_dataset):
    """
    在测试集上评估全局模型性能（准确率和损失）
    """
    model.eval()
    loss, total, correct = 0.0, 0.0, 0.0

    device = 'cuda' if args.gpu else 'cpu'
    criterion = nn.NLLLoss().to(device)

    # 使用 DataLoader 加载测试集
    testloader = DataLoader(test_dataset, batch_size=128, shuffle=False)

    model.to(device)  # 确保模型在正确的设备上

    with torch.no_grad():
        for batch_idx, (images, labels) in enumerate(testloader):
            images, labels = images.to(device), labels.to(device)

            # 推理
            outputs = model(images)
            batch_loss = criterion(outputs, labels)
            loss += batch_loss.item()

            # 计算准确率
            _, pred_labels = torch.max(outputs, 1)
            pred_labels = pred_labels.view(-1)
            correct += torch.sum(torch.eq(pred_labels, labels)).item()
            total += len(labels)

    accuracy = correct / total
    avg_loss = loss / total  # 或者 loss / len(testloader) 取决于 loss 定义，通常是 total

    return accuracy, avg_loss