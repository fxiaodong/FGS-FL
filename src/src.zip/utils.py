#!/usr/bin/env python
# -*- coding: utf-8 -*-
import copy
import torch
import numpy as np
import torch.nn as nn
from torchvision import datasets, transforms
from sampling import (
    mnist_iid, mnist_noniid,
    cifar_iid, cifar_noniid
)
from models import (
    replace_fc_with_lowrank, LowRankFC,
    CNNCifar, CNNMnist, CNNFashion_Mnist, MLP,
    get_fc_rank
)
from uav_utils import init_gt_coords, pso_uav_optimize


# ---------------------------------------------------------------------
def get_dataset(args):
    if args.dataset == 'cifar':
        data_dir = '../data/cifar/'
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
        ])
        train_dataset = datasets.CIFAR10(data_dir, train=True, download=True, transform=transform)
        test_dataset = datasets.CIFAR10(data_dir, train=False, download=True, transform=transform)
        args.num_channels = 3
        user_groups = cifar_iid(train_dataset, args.num_users) if args.iid else cifar_noniid(train_dataset, args.num_users)

    else:  # mnist or fmnist
        data_dir = f'../data/{args.dataset}/'
        ds_cls = datasets.MNIST if args.dataset == 'mnist' else datasets.FashionMNIST
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))
        ])
        train_dataset = ds_cls(data_dir, train=True, download=True, transform=transform)
        test_dataset = ds_cls(data_dir, train=False, download=True, transform=transform)
        args.num_channels = 1
        user_groups = mnist_iid(train_dataset, args.num_users) if args.iid else mnist_noniid(train_dataset, args.num_users)

    return train_dataset, test_dataset, user_groups


# ---------------------------------------------------------------------
def init_uav_and_gt(args):
    gt_coords, gt_powers = init_gt_coords(args)
    uav_coord, gt_rates = pso_uav_optimize(args, gt_coords, gt_powers)
    return uav_coord, gt_coords, gt_rates


# ---------------------------------------------------------------------
def get_fc_layer(model, layer_name):
    module = model
    for name in layer_name.split('.'):
        module = getattr(module, name)
    return module


def get_fc_weight(model, layer_name):
    layer = get_fc_layer(model, layer_name)
    if isinstance(layer, nn.Linear):
        return layer.weight.data
    elif isinstance(layer, LowRankFC):
        return (layer.W1 @ layer.W2).data
    else:
        raise ValueError("Unsupported FC layer type")


# ---------------------------------------------------------------------
def calculate_model_evaluation(model, model_comp):
    w1 = get_fc_weight(model, 'fc1').flatten()
    w2 = get_fc_weight(model_comp, 'fc1').flatten()
    cos = torch.dot(w1, w2) / (torch.norm(w1) * torch.norm(w2) + 1e-9)
    return 0.5 * cos.item() + 0.5


# ---------------------------------------------------------------------
def aggregate_payloads(payloads):
    """FedAvg"""
    total = sum(p['n_samples'] for p in payloads)
    agg = {}

    for p in payloads:
        state = p['state']
        w = p['n_samples'] / total
        for k, v in state.items():
            if k not in agg:
                agg[k] = v * w
            else:
                agg[k] += v * w
    return agg


# ---------------------------------------------------------------------
def build_global_model(args):
    if args.model == 'cnn':
        if args.dataset == 'cifar':
            model = CNNCifar(args)
        elif args.dataset == 'mnist':
            model = CNNMnist(args)
        else:
            model = CNNFashion_Mnist(args)
    elif args.model == 'mlp':
        img = (1, 28, 28) if args.dataset != 'cifar' else (3, 32, 32)
        model = MLP(dim_in=np.prod(img), dim_hidden=128, dim_out=args.num_classes)
    else:
        raise ValueError("Unknown model")

    device = 'cuda' if args.gpu else 'cpu'
    return model.to(device)


# ---------------------------------------------------------------------
def choose_optimal_ro(args, gt_rates, model_size_bits):
    candidate_ro = np.unique(gt_rates)
    min_time = float('inf')
    best_ro = gt_rates.mean()
    best_X = np.ones(args.num_users)

    for ro in candidate_ro:
        X = (gt_rates >= ro).astype(int)
        if X.sum() == 0:
            continue
        T = calculate_fl_time(args, X, gt_rates, model_size_bits)
        if T < min_time:
            min_time = T
            best_X = X
            best_ro = ro

    return best_ro, best_X, min_time


# ---------------------------------------------------------------------
def calculate_fl_time(args, X, gt_rates, model_size_bits):
    compress_rank = getattr(args, 'compress_rank', 10)

    model = build_global_model(args)
    fc = get_fc_layer(model, args.compress_layers)
    lambda_total = get_fc_rank(fc)
    eta = compress_rank / lambda_total

    model_size_compressed = model_size_bits * eta

    T = []
    for m in range(args.num_users):
        D = 600
        C = 100
        f = 1e9
        T_train = (D * C) / f

        upload = model_size_bits * X[m] + model_size_compressed * (1 - X[m])
        T_upload = upload / gt_rates[m]

        T_broadcast = model_size_bits / (gt_rates[m] * 2)

        T.append(T_train + T_upload + T_broadcast)

    return np.mean(T)


# ---------------------------------------------------------------------
def optimize_compression_rank(args, gt_rates, train_dataset, user_groups):
    model = build_global_model(args)
    fc = get_fc_layer(model, args.compress_layers)
    lambda_total = get_fc_rank(fc)

    ranks = np.linspace(1, min(args.compress_rank_max, lambda_total), 10).astype(int)
    ranks = np.unique(ranks)

    min_loss = float('inf')
    best_rank = 10

    size_bytes = sum(p.numel() * 4 for p in model.parameters())
    size_bits = size_bytes * 8

    _, X, _ = choose_optimal_ro(args, gt_rates, size_bits)

    for r in ranks:
        args.compress_rank = r
        global_model = build_global_model(args)
        loss = train_one_round(args, global_model, train_dataset, user_groups, X)
        if loss < min_loss:
            min_loss = loss
            best_rank = r

    args.compress_rank = best_rank
    args.compression_rate = best_rank / lambda_total
    return best_rank, args.compression_rate


# ---------------------------------------------------------------------
def train_one_round(args, global_model, train_dataset, user_groups, X):
    device = 'cuda' if args.gpu else 'cpu'
    updates = []

    for m in range(args.num_users):
        if X[m] == 0 and not args.use_csmc:
            continue

        model = copy.deepcopy(global_model)
        if X[m] == 0 and args.use_csmc:
            model = replace_fc_with_lowrank(model, args.compress_layers, args.compress_rank)

        loader = torch.utils.data.DataLoader(
            torch.utils.data.Subset(train_dataset, user_groups[m]),
            batch_size=args.local_bs,
            shuffle=True
        )

        opt = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)
        criterion = nn.NLLLoss().to(device)
        local_loss = 0.0

        for _ in range(args.local_ep):
            batch_loss = 0.0
            for imgs, labels in loader:
                imgs, labels = imgs.to(device), labels.to(device)
                opt.zero_grad()
                output = model(imgs)
                loss = criterion(output, labels)
                loss.backward()
                opt.step()
                batch_loss += loss.item() * imgs.size(0)
            local_loss += batch_loss / len(loader.dataset)

        updates.append({
            'state': model.state_dict(),
            'n_samples': len(user_groups[m]),
            'loss': local_loss / args.local_ep,
        })

    if updates:
        agg = aggregate_payloads(updates)
        global_model.load_state_dict(agg)
        return np.mean([u['loss'] for u in updates])
    else:
        return float('inf')


# ---------------------------------------------------------------------
def exp_details(args):
    print("\n=== 实验参数 ===")
    print(f"数据集: {args.dataset} | 模型: {args.model}")
    print(f"GT数量: {args.num_users} | 全局轮次: {args.epochs}")
    print(f"策略: {args.strategy}")
    if args.use_csmc:
        print(f"压缩层: {args.compress_layers} | 压缩率: {args.compression_rate:.2f}")
    print("================\n")
