#!/usr/bin/env python
# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------
# ★ 低秩全连接层（替代 nn.Linear）
# ---------------------------------------------------------------------
class LowRankFC(nn.Module):
    def __init__(self, in_features, out_features, rank):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.rank = rank

        # W ≈ W1 @ W2  where:
        # W1: (out_features, rank)
        # W2: (rank, in_features)
        self.W1 = nn.Parameter(torch.randn(out_features, rank) * 0.01)
        self.W2 = nn.Parameter(torch.randn(rank, in_features) * 0.01)
        self.bias = nn.Parameter(torch.zeros(out_features))

    def forward(self, x):
        weight = self.W1 @ self.W2
        return F.linear(x, weight, self.bias)


# ---------------------------------------------------------------------
# ★ CNN for MNIST / FashionMNIST
# ---------------------------------------------------------------------
class CNNMnist(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 10, 5)
        self.conv2 = nn.Conv2d(10, 20, 5)
        self.fc1 = nn.Linear(320, args.num_classes)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2(x), 2))
        x = x.view(-1, 320)
        out = self.fc1(x)
        return F.log_softmax(out, dim=1)


# ---------------------------------------------------------------------
# ★ CNN for FashionMNIST
# ---------------------------------------------------------------------
class CNNFashion_Mnist(CNNMnist):
    pass


# ---------------------------------------------------------------------
# ★ CNN for CIFAR10
# ---------------------------------------------------------------------
class CNNCifar(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, args.num_classes)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2(x), 2))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        out = self.fc2(x)
        return F.log_softmax(out, dim=1)


# ---------------------------------------------------------------------
# ★ 多层感知机，修复参数错误问题
# ---------------------------------------------------------------------
class MLP(nn.Module):
    def __init__(self, dim_in=784, dim_hidden=200, dim_out=10):
        super().__init__()
        self.fc1 = nn.Linear(dim_in, dim_hidden)
        self.fc2 = nn.Linear(dim_hidden, dim_out)

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        out = self.fc2(x)
        return F.log_softmax(out, dim=1)


# ---------------------------------------------------------------------
# ★ 工具函数：计算奇异值数量（rank）
# ---------------------------------------------------------------------
def get_fc_rank(fc_layer):
    if isinstance(fc_layer, nn.Linear):
        W = fc_layer.weight.data
    elif isinstance(fc_layer, LowRankFC):
        W = (fc_layer.W1 @ fc_layer.W2).data
    else:
        raise ValueError("Unsupported FC layer type")
    return min(W.size(0), W.size(1))


# ---------------------------------------------------------------------
# ★ 将模型中的某一层替换为低秩层
# ---------------------------------------------------------------------
def replace_fc_with_lowrank(model, layer_name, rank):
    layers = layer_name.split('.')
    module = model
    for p in layers[:-1]:
        module = getattr(module, p)
    last = layers[-1]

    fc = getattr(module, last)
    in_f = fc.in_features
    out_f = fc.out_features

    # SVD 分解（torch.linalg.svd）
    W = fc.weight.data
    U, S, Vh = torch.linalg.svd(W, full_matrices=False)

    # 截断到 rank
    U_r = U[:, :rank]
    S_r = S[:rank]
    V_r = Vh[:rank, :]

    new_fc = LowRankFC(in_f, out_f, rank)
    new_fc.W1.data = U_r @ torch.diag(torch.sqrt(S_r))
    new_fc.W2.data = torch.diag(torch.sqrt(S_r)) @ V_r
    new_fc.bias.data = fc.bias.data.clone()

    setattr(module, last, new_fc)
    return model
