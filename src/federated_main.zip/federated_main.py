#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import copy
import time
import numpy as np
import torch
from tensorboardX import SummaryWriter
from options import args_parser
from update import LocalUpdate, test_inference
from utils import (
    get_dataset,
    init_uav_and_gt,
    choose_optimal_ro,
    aggregate_payloads,
    exp_details,
    build_global_model,
    train_one_round,
    get_fc_rank,
    get_fc_layer
)


def compute_model_size_bits(model: torch.nn.Module) -> int:
    """计算模型大小（比特），假设 float32 -> 4 字节/参数"""
    model_size_bytes = sum(p.numel() for p in model.parameters()) * 4
    return int(model_size_bytes * 8)


def main():
    start_time = time.time()
    args = args_parser()

    # 修正：定义精确的 device 字符串并处理 GPU ID 类型
    if args.gpu is not None and args.gpu != 'None':
        # 1. 将 args.gpu 转换为整数 (int)
        try:
            gpu_id = int(args.gpu)
            device = f'cuda:{gpu_id}'

            # 2. 传递整数给 set_device
            torch.cuda.set_device(gpu_id)
        except ValueError:
            # 如果转换失败，退回到 CPU
            print(f"警告：GPU ID '{args.gpu}' 无效，使用 CPU。")
            device = 'cpu'
    else:
        device = 'cpu'

    logger = SummaryWriter('../logs')

    # 1. 加载数据
    train_dataset, test_dataset, user_groups = get_dataset(args)

    # 2. 初始化 UAV 与 GT
    args.uav_coord, args.gt_coords, args.gt_rates = init_uav_and_gt(args)

    # 3. 策略优化初始化
    # 默认初始化：不压缩（全部原模型）
    args.optimal_X = np.ones(args.num_users, dtype=int)
    args.compression_rate = 1.0
    args.compress_rank = getattr(args, 'compress_rank', 10)  # 默认rank

    # 基础模型（用于获取参数结构和全秩大小）
    tmp_model = build_global_model(args)
    full_model_size_bits = compute_model_size_bits(tmp_model)
    fc_layer = get_fc_layer(tmp_model, args.compress_layers)
    lambda_total = get_fc_rank(fc_layer)  # 全秩大小
    # 修正：确保初始模型在正确的设备上
    tmp_model.to(device)

    if args.strategy == 'tFL':
        args.use_csmc = 0
        args.optimal_X = np.ones(args.num_users, dtype=int)
        args.compression_rate = 1.0

    elif args.strategy == 'psFL':
        args.use_csmc = 0
        # 选择信道最好的前50%用户
        K = max(1, int(args.num_users * 0.5))
        top_k_idx = np.argsort(args.gt_rates)[-K:]
        args.optimal_X = np.zeros(args.num_users, dtype=int)
        args.optimal_X[top_k_idx] = 1  # 1=参与, 0=不参与
        args.compression_rate = 1.0

    elif args.strategy == 'csmcFL' or args.use_csmc:
        args.use_csmc = 1
        print("\n=== 开始 csmcFL 联合优化 (交替迭代) ===")

        # 论文 Algorithm 2: 交替优化 压缩率(eta) 和 客户端选择(X)
        # 初始化：假设所有用户都参与，均为全模型 (X=1)
        current_X = np.ones(args.num_users, dtype=int)
        current_rank = args.compress_rank

        # 设置最大迭代次数，并引入收敛检查
        MAX_JOINT_ITER = 5
        for iter_step in range(MAX_JOINT_ITER):
            print(f"--- Joint Optimization Iteration {iter_step + 1} ---")

            # 记录上一轮状态 (用于收敛检查)
            prev_X = current_X.copy()
            prev_rank = current_rank

            # Step A: 固定 X，优化压缩率 (rank)
            best_rank = current_rank
            min_loss_search = float('inf')

            # 生成候选 ranks (例如 10% 到 90% 的全秩)
            candidate_ranks = np.linspace(1, min(args.compress_rank_max, lambda_total), 5).astype(int)
            candidate_ranks = np.unique(candidate_ranks)
            if len(candidate_ranks) == 0: candidate_ranks = [10]

            for r in candidate_ranks:
                # 临时更新 args
                args.compress_rank = int(r)
                args.compression_rate = r / lambda_total

                # 试训练一轮，评估 Loss
                # 注意：这里需要重新构建临时模型，并确保它在正确的设备上
                tmp_global = build_global_model(args)
                tmp_global.to(device)
                # train_one_round 内部会自己处理 device，因此只传入 5 个参数
                loss_r = train_one_round(args, tmp_global, train_dataset, user_groups, current_X)

                if loss_r < min_loss_search:
                    min_loss_search = loss_r
                    best_rank = int(r)

            # 更新最优 Rank 和 Rate
            current_rank = best_rank
            args.compress_rank = current_rank
            args.compression_rate = current_rank / lambda_total
            print(f"   Updated Optimal Rank: {args.compress_rank} (Rate: {args.compression_rate:.2f})")

            # Step B: 固定压缩率，优化 X (选择策略)
            best_ro, best_X, min_time = choose_optimal_ro(args, args.gt_rates, full_model_size_bits)

            current_X = best_X
            args.optimal_X = best_X
            args.optimal_ro = best_ro
            args.min_fl_time = min_time
            print(f"   Updated Optimal X: Selected {np.sum(current_X == 1)} Full / {np.sum(current_X == 0)} Compressed")

            # 【新增：收敛检查，符合 Algorithm 2 终止条件】
            is_X_converged = np.array_equal(current_X, prev_X)
            is_rank_converged = (current_rank == prev_rank)

            if is_X_converged and is_rank_converged:
                print(f"\n--- 联合优化在第 {iter_step + 1} 轮收敛，提前终止 ---")
                break

        print("=== 联合优化结束 ===\n")

    # 打印实验详细参数
    exp_details(args)

    # 4. 构建全局模型（正式训练开始）
    global_model = build_global_model(args)
    global_model.to(device)

    # 记录变量
    train_loss = []
    train_acc = []
    test_acc_list = []
    eval_scores = []
    total_param_bits = []

    # 6. 全局训练循环
    for epoch in range(args.epochs):
        print(f'\n=== 全局训练轮次 {epoch + 1}/{args.epochs} ===')
        global_model.train()

        # 确定本轮参与的客户端
        if args.strategy == 'psFL':
            selected_users = np.where(args.optimal_X == 1)[0]
        else:
            selected_users = np.arange(args.num_users)

        local_payloads = []
        local_losses = []

        # 对每个客户端进行本地训练
        for idx in selected_users:
            idxs = user_groups[idx]
            local_trainer = LocalUpdate(args=args, dataset=train_dataset, idxs=idxs, logger=logger)

            # 决定是否压缩
            is_compressed_user = False
            if args.strategy == 'csmcFL' and args.optimal_X[idx] == 0:
                is_compressed_user = True

            # 执行本地训练
            payload, loss = local_trainer.update_weights(
                model=copy.deepcopy(global_model),
                global_round=epoch,
                compress=is_compressed_user
            )
            local_payloads.append(payload)
            local_losses.append(loss)

        # 计算模型一致性评价指标 (Model Evaluation)
        current_eval_score = 1.0
        if args.strategy == 'csmcFL':
            payloads_full = []
            payloads_comp = []

            for i, u_idx in enumerate(selected_users):
                if args.optimal_X[u_idx] == 1:
                    payloads_full.append(local_payloads[i])
                else:
                    payloads_comp.append(local_payloads[i])

            if len(payloads_full) > 0 and len(payloads_comp) > 0:
                agg_full = aggregate_payloads(payloads_full)
                agg_comp = aggregate_payloads(payloads_comp)

                target_key = f"{args.compress_layers}.weight"
                if target_key in agg_full and target_key in agg_comp:
                    w_full = agg_full[target_key].flatten()
                    w_comp = agg_comp[target_key].flatten()

                    cos_sim = torch.dot(w_full, w_comp) / (torch.norm(w_full) * torch.norm(w_comp) + 1e-9)
                    current_eval_score = 0.5 * cos_sim.item() + 0.5

        eval_scores.append(current_eval_score)

        # 聚合模型
        if len(local_payloads) > 0:
            agg_state = aggregate_payloads(local_payloads)
            global_model.load_state_dict(agg_state)

        # 记录 Loss
        avg_loss = sum(local_losses) / len(local_losses) if local_losses else 0.0
        train_loss.append(avg_loss)

        # 统计精度与传输量
        total_bits = 0.0

        # 传输比特统计
        for i, idx in enumerate(selected_users):
            if args.strategy == 'csmcFL' and args.optimal_X[idx] == 0:
                param_bits = full_model_size_bits * args.compression_rate
            else:
                param_bits = full_model_size_bits
            total_bits += param_bits

        # 简单使用测试集评估 global model
        test_acc, test_loss = test_inference(args, global_model, test_dataset)
        test_acc_list.append(test_acc)
        total_param_bits.append(total_bits)

        # 打印本轮结果
        print(f'=== 轮次 {epoch + 1} 指标 ===')
        print(f'训练损失: {avg_loss:.4f} | 测试准确率: {test_acc:.2%}')
        if args.strategy == 'csmcFL':
            print(f'模型一致性评分 (Similarity): {current_eval_score:.4f}')
        print(f'本轮总传输量: {total_bits / 1e6:.2f} Mbits')
        print('======================\n')

    # 7. 保存结果
    save_dir = '../save/results/'
    os.makedirs(save_dir, exist_ok=True)
    result = {
        'train_loss': train_loss,
        'test_acc': test_acc_list,
        'eval_scores': eval_scores,
        'total_param_bits': total_param_bits,
        'args': args.__dict__
    }

    filename = f'{args.strategy}_{args.dataset}_{"IID" if args.iid else "NonIID"}.pth'
    torch.save(result, os.path.join(save_dir, filename))

    # 8. 最终打印
    best_test = max(test_acc_list) if len(test_acc_list) > 0 else 0.0
    avg_time = getattr(args, 'min_fl_time', 0.0)

    print(f'最高测试准确率: {best_test:.2%}')
    if args.strategy == 'csmcFL':
        print(f'预估平均单轮 FL 时间: {avg_time:.2f} s')
    print(f'总运行时间: {time.time() - start_time:.2f} s')


if __name__ == '__main__':
    main()